package com.chessweeper.game;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> fileCallback; private static final int PICK_FILE=51;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  web=new WebView(this);setContentView(web);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
  web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{Intent i=p.createIntent();startActivityForResult(i,PICK_FILE);return true;}catch(Exception e){fileCallback=null;return false;}}});
  web.addJavascriptInterface(new Object(){@JavascriptInterface public void save(String name,String base64){runOnUiThread(()->{try{String safe=name.replaceAll("[^a-zA-Z0-9._-]","_");if(safe.length()==0)safe="chessweeper-save.json";byte[] bytes=Base64.decode(base64,Base64.DEFAULT);ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,safe);cv.put(MediaStore.Downloads.MIME_TYPE,"application/json");if(Build.VERSION.SDK_INT>=29)cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);if(uri==null)throw new Exception("No URI");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}Toast.makeText(this,"Сохранение скачано",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Не удалось сохранить файл: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}},"AndroidSave");
  web.setDownloadListener((url,userAgent,contentDisposition,mimeType,length)->{if(url.startsWith("data:")){try{String data=url.substring(url.indexOf(',')+1);String filename="chessweeper-save.json";web.evaluateJavascript("(function(){var a=document.querySelector('a[download]');return a?a.getAttribute('download'):''})()",v->{});web.evaluateJavascript("AndroidSave.save('"+filename+"','"+data.replace("'","")+"')",null);}catch(Exception e){Toast.makeText(this,"Ошибка экспорта",Toast.LENGTH_SHORT).show();}}});
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_FILE&&fileCallback!=null){fileCallback.onReceiveValue(c==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null);fileCallback=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
